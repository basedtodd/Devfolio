'use client';

import Hero from "@/components/hero/page";

export default function Home() {
  return (
    <main className="" >
      <Hero />
    </main>
  );
}
